# Pacote do servidor de matchmaking

Este pacote contém o executável Linux do servidor gRPC e o pequeno cliente
Python de matchmaking para testar chamadas. Ele não inclui o jogo nem as
dependências de desenvolvimento do projeto.

O pacote é gerado para a arquitetura da máquina que o compilou. A máquina de
destino deve usar a mesma arquitetura e ter versões compatíveis de glibc e da
biblioteca padrão do C++. O executável gRPC é linkado estaticamente com as
bibliotecas do projeto; não é necessário instalar Conan, CMake ou gRPC C++ na
máquina de destino.

## Gerar o pacote

Em uma máquina Linux, na raiz do repositório, execute:

```sh
./scripts/package.sh
```

O script compila o projeto, executa os testes unitários do cliente Python e cria:

```text
output/matchplayers-server-linux-<arquitetura>.tar.gz
```

Por exemplo, em uma máquina x86-64:
`output/matchplayers-server-linux-x86_64.tar.gz`.

Copie esse arquivo para a outra máquina Linux, por exemplo com `scp` ou uma
mídia removível.

### Compatibilidade entre versões do Linux

O pacote depende da glibc e da `libstdc++` instaladas no sistema de destino.
Ele funciona quando essas bibliotecas são da mesma versão ou mais novas que as
usadas para compilá-lo. O script de empacotamento informa as versões mínimas
detectadas no executável.

Para executar em uma distribuição mais antiga, compile e empacote nela ou em
um ambiente de build com ABI compatível. Por exemplo, para Lubuntu/Ubuntu
20.04, gere o pacote em Lubuntu/Ubuntu 20.04; um executável compilado no Ubuntu
22.04 pode precisar de GLIBC 2.34 ou superior, enquanto o Ubuntu 20.04 fornece
GLIBC 2.31. Não há uma opção de empacotamento que remova essa dependência do
binário já compilado.

## Instalar e iniciar

Na máquina de destino:

```sh
tar -xzf matchplayers-server-linux-*.tar.gz
cd matchplayers-server-linux-*/
./scripts/match_server.sh 50051
```

O argumento é opcional; se omitido, a porta padrão é `50051`. Para encerrar o
servidor, pressione `Ctrl+C`.

O servidor escuta em `0.0.0.0`, isto é, aceita conexões em todas as interfaces
de rede da máquina. Clientes em outros computadores devem usar o IP alcançável
da máquina servidora e a porta escolhida, como `192.168.1.10:50051`. Não use
`0.0.0.0` no endereço do cliente: esse endereço serve apenas para configurar
onde o servidor escuta. Libere a porta TCP do serviço no firewall.

O pacote também fornece atalhos em `scripts/`: `./scripts/player.sh` inicia um
jogador e `./scripts/display.sh` inicia o display. No pacote extraído, prepare
primeiro o ambiente Python com `./scripts/setup_runtime.sh`.

## Testar o matchmaking

O pacote inclui o jogo Blackjack e o cliente Python em
`python/21_blackjack/app/matchmaking_client/`, além do script
`setup_runtime.sh` para preparar o ambiente Python. No computador cliente,
instale Python 3.8 ou superior, `python3-venv` e `python3-pip`; depois, a partir
da raiz do pacote, execute:

```sh
./scripts/setup_runtime.sh
```

Com o servidor em execução, teste o RPC enviando dois jogadores de teste
simultaneamente:

```sh
.venv/bin/python scripts/test_match_server.py \
  --server 192.168.1.10:50051 --ip 192.168.1.20
```

O script verifica se cada resposta aponta para o outro jogador e se ambas
informam o mesmo identificador de partida. Para testar um servidor na própria
máquina, os argumentos podem ser omitidos:

```sh
.venv/bin/python scripts/test_match_server.py
```

O IP informado com `--ip` é anunciado ao oponente, mas o script não abre
serviços nas portas de jogo. Portanto, esse teste valida o acesso ao servidor
e o pareamento, não a conectividade de gameplay entre dois computadores.

## Executar o Blackjack

Com as dependências instaladas pelo `setup_runtime.sh` e o servidor em
execução, inicie o jogo em cada computador. Aponte ambos para o mesmo endereço
de matchmaking; informe o IP alcançável de cada jogador com `--ip` se a
detecção automática não selecionar a interface correta:

Se o servidor de matchmaking estiver rodando na mesma máquina, abra outro
terminal e use `127.0.0.1` como endereço do servidor e IP anunciado:

```sh
./scripts/player.sh \
  127.0.0.1:50051 --porta 41000 --ip 127.0.0.1 --nome Alice
```

Para iniciar dois jogadores na mesma máquina, execute o mesmo comando em outro
terminal com outro nome e outra porta de jogo, por exemplo `41001`.

```sh
./scripts/player.sh \
  192.168.1.10:50051 --porta 41000 --ip 192.168.1.20 --nome Alice
```

No outro computador, use o endereço desse computador e, se necessário, outra
porta local:

```sh
./scripts/player.sh \
  192.168.1.10:50051 --porta 41000 --ip 192.168.1.21 --nome Bruno
```

O cliente abre a escuta TCP antes de pedir a partida. O campo `starts` define
quem conecta e quem aceita; o Blackjack usa a conexão TCP existente para
trocar as mensagens da partida. O firewall precisa permitir a porta gRPC do
servidor e a porta TCP do jogo entre os jogadores.

Em outro terminal, inicie o display para acompanhar a partida:

```sh
./scripts/display.sh
```
