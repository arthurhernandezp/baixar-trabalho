#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [[ -x "$SCRIPT_DIR/../bin/match_server" ]]; then
    exec "$SCRIPT_DIR/../bin/match_server" "$@"
fi

if [[ -x "$SCRIPT_DIR/../build/match_server" ]]; then
    exec "$SCRIPT_DIR/../build/match_server" "$@"
fi

echo "Executável match_server não encontrado. Execute scripts/build.sh primeiro." >&2
exit 1

# Exemplo: ./scripts/match_server.sh 50051
