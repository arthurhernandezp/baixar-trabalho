#!/usr/bin/env python3
"""Testa o matchmaking real enviando duas solicitacoes simultaneas."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "python/21_blackjack/app"))

import grpc

from matchmaking_client import find_opponent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Envia dois jogadores de teste ao servidor de matchmaking."
    )
    parser.add_argument(
        "--server",
        default="127.0.0.1:50051",
        help="Endereco host:porta do servidor (padrao: 127.0.0.1:50051).",
    )
    parser.add_argument(
        "--ip",
        default="127.0.0.1",
        help="IP anunciado pelos jogadores de teste (padrao: 127.0.0.1).",
    )
    parser.add_argument(
        "--port-1",
        type=int,
        default=41001,
        help="Porta de jogo anunciada pelo primeiro jogador (padrao: 41001).",
    )
    parser.add_argument(
        "--port-2",
        type=int,
        default=41002,
        help="Porta de jogo anunciada pelo segundo jogador (padrao: 41002).",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=125,
        help="Tempo maximo de espera em segundos (padrao: 125).",
    )
    args = parser.parse_args()

    for label, port in (("--port-1", args.port_1), ("--port-2", args.port_2)):
        if not 1 <= port <= 65535:
            parser.error(f"{label} deve estar entre 1 e 65535")
    if args.port_1 == args.port_2:
        parser.error("--port-1 e --port-2 devem ser diferentes")
    if args.timeout <= 0:
        parser.error("--timeout deve ser maior que zero")

    return args


def main() -> int:
    args = parse_args()
    players = (
        ("jogador-teste-1", args.port_1),
        ("jogador-teste-2", args.port_2),
    )

    try:
        with ThreadPoolExecutor(max_workers=2) as executor:
            requests = [
                executor.submit(
                    find_opponent,
                    args.server,
                    args.ip,
                    port,
                    player_name=name,
                    timeout=args.timeout,
                )
                for name, port in players
            ]
            opponents = [request.result() for request in requests]
    except grpc.RpcError as error:
        print(
            f"Falha ao testar {args.server}: {error.code().name}: "
            f"{error.details()}",
            file=sys.stderr,
        )
        return 1

    first, second = opponents
    valid_match = (
        first.ip == args.ip
        and first.port == args.port_2
        and second.ip == args.ip
        and second.port == args.port_1
        and first.match_id
        and first.match_id == second.match_id
        and first.starts != second.starts
    )
    if not valid_match:
        print("Falha: as respostas do servidor nao formaram um par reciproco.", file=sys.stderr)
        print(f"Resposta do jogador 1: {first}", file=sys.stderr)
        print(f"Resposta do jogador 2: {second}", file=sys.stderr)
        return 1

    print(f"Teste concluido: partida {first.match_id}")
    print(
        f"{players[0][0]} encontrou {first.ip}:{first.port} "
        f"(starts={first.starts})"
    )
    print(
        f"{players[1][0]} encontrou {second.ip}:{second.port} "
        f"(starts={second.starts})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
