#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -d "$SCRIPT_DIR/python/21_blackjack/app" ]]; then
    ROOT="$SCRIPT_DIR"
else
    ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"
fi

if [[ -x "$ROOT/.venv/bin/python" ]]; then
    PYTHON="$ROOT/.venv/bin/python"
elif command -v python3 >/dev/null 2>&1; then
    PYTHON="$(command -v python3)"
else
    echo "Python 3 não encontrado. Instale Python 3.8 ou superior." >&2
    exit 1
fi

exec "$PYTHON" "$ROOT/python/21_blackjack/app/display.py" "$@"

# Exemplo: ./scripts/display.sh
