#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 não encontrado. Instale Python 3.8 ou superior e python3-venv." >&2
    exit 1
fi

if python3 -c 'import venv, ensurepip' >/dev/null 2>&1; then
    python3 -m venv --clear "$ROOT/.venv"
elif python3 -m virtualenv --version >/dev/null 2>&1; then
    python3 -m virtualenv --clear "$ROOT/.venv"
else
    echo "Módulo venv ausente para $(python3 --version)." >&2
    echo "No Ubuntu/Lubuntu/Debian, instale-o com:" >&2
    echo "  sudo apt update && sudo apt install python3-venv python3-pip" >&2
    echo "Se estiver usando uma versão específica do Python, instale o pacote correspondente, por exemplo python3.10-venv." >&2
    exit 1
fi

"$ROOT/.venv/bin/python" -m pip install -r "$ROOT/requirements.txt"

echo "Ambiente de execução pronto em $ROOT/.venv"
