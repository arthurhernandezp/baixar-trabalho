import unittest
import sys
from pathlib import Path
from unittest.mock import Mock, patch

APP_DIR = Path(__file__).resolve().parents[1] / "app"
sys.path.insert(0, str(APP_DIR))

from matchmaking_client import Opponent, find_opponent
from matchmaking_client import client


class MatchmakingClientTest(unittest.TestCase):
    @patch.object(client.grpc, "insecure_channel")
    @patch.object(client.matchmaking_pb2_grpc, "MatchmakingStub")
    def test_find_opponent_returns_connection_details(self, stub_class, channel_factory):
        channel = Mock()
        channel_factory.return_value = channel
        stub = stub_class.return_value
        stub.FindOpponent.return_value = client.matchmaking_pb2.MatchResponse(
            ip="192.168.1.20",
            port=41002,
            starts=False,
            match_id="match-7",
        )

        result = find_opponent(
            "match.example.com:50051",
            "192.168.1.10",
            41001,
            player_name="Alice",
            timeout=30,
        )

        self.assertEqual(
            result,
            Opponent(
                ip="192.168.1.20",
                port=41002,
                starts=False,
                match_id="match-7",
            ),
        )
        request = stub.FindOpponent.call_args.args[0]
        self.assertEqual(request.ip, "192.168.1.10")
        self.assertEqual(request.port, 41001)
        self.assertEqual(request.player_name, "Alice")
        self.assertNotIn("protocol", request.DESCRIPTOR.fields_by_name)
        self.assertEqual(stub.FindOpponent.call_args.kwargs["timeout"], 30)
        channel.close.assert_called_once_with()

    def test_find_opponent_rejects_invalid_port(self):
        with self.assertRaises(ValueError):
            find_opponent("localhost:50051", "127.0.0.1", 0)


if __name__ == "__main__":
    unittest.main()
