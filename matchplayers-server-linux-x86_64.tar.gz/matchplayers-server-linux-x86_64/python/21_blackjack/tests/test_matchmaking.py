import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch


GAME_ROOT = Path(__file__).resolve().parents[1]
APP_DIR = GAME_ROOT / "app"
sys.path.insert(0, str(APP_DIR))

import vinteum
from matchmaking_client import Opponent


class MatchmakingIntegrationTest(unittest.TestCase):
    def setUp(self):
        self.listener = Mock()
        self.connection = Mock()
        self.opponent = Opponent(
            ip="192.168.1.30",
            port=41000,
            starts=True,
            match_id="match-1",
        )

    @patch.object(vinteum, "jogar")
    @patch.object(vinteum.conexao, "conectar")
    @patch.object(vinteum, "find_opponent")
    @patch.object(vinteum.conexao, "abrir_escuta")
    @patch.object(vinteum, "obter_ip_anunciavel", return_value="192.168.1.20")
    def test_dealer_connects_to_opponent(
        self,
        _discover_ip,
        listen,
        find_match,
        connect,
        play,
    ):
        listen.return_value = self.listener
        find_match.return_value = self.opponent
        connect.return_value = self.connection

        result = vinteum.main(["192.168.1.10:50051", "--porta", "41000"])

        self.assertEqual(result, 0)
        find_match.assert_called_once_with(
            "192.168.1.10:50051",
            "192.168.1.20",
            41000,
            player_name=vinteum.socket.gethostname(),
        )
        connect.assert_called_once_with("192.168.1.30", 41000)
        play.assert_called_once_with(self.connection, True, False)
        self.listener.close.assert_called_once_with()
        self.connection.fechar.assert_called_once_with()

    @patch.object(vinteum, "jogar")
    @patch.object(vinteum.conexao, "aguardar")
    @patch.object(vinteum, "find_opponent")
    @patch.object(vinteum.conexao, "abrir_escuta")
    @patch.object(vinteum, "obter_ip_anunciavel", return_value="192.168.1.20")
    def test_non_dealer_accepts_opponent_connection(
        self,
        _discover_ip,
        listen,
        find_match,
        accept,
        play,
    ):
        listen.return_value = self.listener
        find_match.return_value = Opponent(
            ip="192.168.1.30",
            port=41000,
            starts=False,
            match_id="match-1",
        )
        accept.return_value = self.connection

        result = vinteum.main(["192.168.1.10:50051"])

        self.assertEqual(result, 0)
        accept.assert_called_once_with(41000, self.listener)
        play.assert_called_once_with(self.connection, False, False)
        self.listener.close.assert_called_once_with()
        self.connection.fechar.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
