"""Blackjack entre dois jogadores com pareamento pelo servidor gRPC."""

import argparse
import ipaddress
import socket
import sys

import grpc
from matchmaking_client import find_opponent

import conexao
from jogo import jogar


def obter_ip_anunciavel(endereco_servidor):
    """Descobre o IPv4 local usado para alcançar o servidor de matchmaking."""
    host, separator, porta_text = endereco_servidor.rpartition(":")
    if not separator or not host or not porta_text.isdigit():
        raise ValueError("Servidor deve estar no formato HOST:PORTA")
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]

    try:
        destinos = socket.getaddrinfo(
            host,
            int(porta_text),
            family=socket.AF_INET,
            type=socket.SOCK_DGRAM,
        )
    except OSError as error:
        raise ValueError(f"Não foi possível resolver o servidor {host}: {error}") from error

    for familia, tipo, protocolo, _, destino in destinos:
        with socket.socket(familia, tipo, protocolo) as probe:
            try:
                probe.connect(destino)
            except OSError:
                continue
            ip = probe.getsockname()[0]
            if not ipaddress.ip_address(ip).is_loopback:
                return ip

    raise ValueError(
        "Não foi possível descobrir um IP de rede para anunciar. "
        "Informe-o manualmente com --ip."
    )


def criar_parser():
    parser = argparse.ArgumentParser(
        description="Encontra um oponente no servidor de matchmaking e inicia o Blackjack."
    )
    parser.add_argument(
        "servidor_match",
        help="Endereço HOST:PORTA do servidor de matchmaking, por exemplo 192.168.1.10:50051.",
    )
    parser.add_argument(
        "--porta",
        type=int,
        default=41000,
        help="Porta TCP local do jogo (padrão: 41000).",
    )
    parser.add_argument(
        "--ip",
        dest="ip_anunciavel",
        help="IP local alcançável pelo oponente; por padrão é detectado pela rota ao servidor.",
    )
    parser.add_argument(
        "--nome",
        default=socket.gethostname(),
        help="Nome informativo do jogador (padrão: nome da máquina).",
    )
    parser.add_argument("--debug", action="store_true", help="Exibe informações de depuração.")
    return parser


def main(argv=None):
    parser = criar_parser()
    args = parser.parse_args(argv)
    if not 1 <= args.porta <= 65535:
        parser.error("--porta deve estar entre 1 e 65535")

    ip_anunciavel = args.ip_anunciavel
    listener = None
    con = None
    try:
        ip_anunciavel = ip_anunciavel or obter_ip_anunciavel(args.servidor_match)
        if ipaddress.ip_address(ip_anunciavel).version != 4:
            raise ValueError("O jogo anuncia endereços IPv4 e precisa de um IP IPv4.")

        # A porta de jogo fica pronta antes de o matchmaking anunciar o jogador.
        listener = conexao.abrir_escuta(args.porta)
        print(f"Buscando partida em {args.servidor_match}...")
        print(f"Endereço anunciado: {ip_anunciavel}:{args.porta}")
        oponente = find_opponent(
            args.servidor_match,
            ip_anunciavel,
            args.porta,
            player_name=args.nome,
        )
        print(f"Oponente encontrado em {oponente.ip}:{oponente.port}")

        if oponente.starts:
            listener.close()
            listener = None
            print("Você será o Dealer e iniciará a conexão.")
            con = conexao.conectar(oponente.ip, oponente.port)
        else:
            print("Você aguardará a conexão do Dealer.")
            con = conexao.aguardar(args.porta, listener)
            listener.close()
            listener = None

        jogar(con, oponente.starts, args.debug)
        return 0
    except grpc.RpcError as error:
        print(
            f"\nFalha no matchmaking: {error.code().name}: {error.details()}",
            file=sys.stderr,
        )
        return 1
    except (ConnectionError, OSError, ValueError) as error:
        print(f"\nNão foi possível iniciar a partida: {error}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nBusca de partida cancelada.")
        return 130
    finally:
        if listener is not None:
            listener.close()
        if con:
            con.fechar()


if __name__ == "__main__":
    raise SystemExit(main())