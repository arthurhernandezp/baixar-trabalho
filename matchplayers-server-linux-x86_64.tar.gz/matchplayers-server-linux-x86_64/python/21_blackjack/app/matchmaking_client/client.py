from dataclasses import dataclass

import grpc

from . import matchmaking_pb2, matchmaking_pb2_grpc


@dataclass(frozen=True)
class Opponent:
    ip: str
    port: int
    starts: bool
    match_id: str


def find_opponent(
    match_server: str,
    advertise_ip: str,
    listen_port: int,
    player_name: str = "",
    timeout: float = 125,
) -> Opponent:
    """Aguarda um pareamento e retorna os dados de conexão do oponente."""
    if not match_server:
        raise ValueError("match_server nao pode ser vazio")
    if not advertise_ip:
        raise ValueError("advertise_ip nao pode ser vazio")
    if not 1 <= listen_port <= 65535:
        raise ValueError("listen_port deve estar entre 1 e 65535")
    if not player_name:
        player_name = "player"
    if timeout <= 0:
        raise ValueError("timeout deve ser maior que zero")

    channel = grpc.insecure_channel(match_server)
    try:
        stub = matchmaking_pb2_grpc.MatchmakingStub(channel)
        request = matchmaking_pb2.MatchRequest(
            ip=advertise_ip,
            port=listen_port,
            player_name=player_name,
        )
        response = stub.FindOpponent(request, timeout=timeout)
    finally:
        channel.close()

    return Opponent(
        ip=response.ip,
        port=response.port,
        starts=response.starts,
        match_id=response.match_id,
    )
