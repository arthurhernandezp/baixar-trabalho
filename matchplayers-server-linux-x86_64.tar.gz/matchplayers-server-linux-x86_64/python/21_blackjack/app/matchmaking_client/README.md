# Cliente Python de matchmaking

Este diretório contém um módulo pequeno e independente para um cliente Python
pedir uma partida ao servidor gRPC de matchmaking. Ele envia o endereço em que
o jogador pode ser alcançado e espera até o servidor encontrar um oponente.

O módulo não implementa conexão com o oponente, regras do jogo, interface,
troca de jogadas nem protocolo de gameplay. Depois que o servidor retorna os
dados do pareamento, cabe ao jogo usar essas informações para iniciar sua
própria conexão e comunicação.

## Arquivos do diretório

- `__init__.py`: expõe a função `find_opponent` e a classe `Opponent` na
  interface pública do pacote.
- `client.py`: valida os argumentos, faz a chamada gRPC e converte a resposta
  do servidor em um objeto `Opponent`.
- `matchmaking_pb2.py`: mensagens Protobuf do contrato, geradas a partir do
  arquivo `proto/matchmaking.proto`.
- `matchmaking_pb2_grpc.py`: cliente gRPC gerado para chamar o método
  `FindOpponent`.

Os dois arquivos `matchmaking_pb2*.py` são gerados automaticamente. Não os
edite manualmente; se o contrato Protobuf mudar, regenere-os seguindo a seção
**Atualizar o contrato gRPC**.

## Requisitos

O módulo precisa das bibliotecas de execução `grpcio` e `protobuf`. No projeto
atual, as versões usadas são:

```sh
python -m pip install grpcio==1.54.3 protobuf==4.23.4
```

Não é necessário instalar `grpcio-tools` para apenas usar o cliente. Essa
ferramenta só é necessária para regenerar os arquivos Protobuf/gRPC.

O cliente fica dentro de `python/21_blackjack/app/` e é importado pelo jogo
diretamente, sem configuração adicional de `PYTHONPATH`. Para testar a
importação a partir da raiz:

```sh
PYTHONPATH=python/21_blackjack/app python -c "from matchmaking_client import find_opponent"
```

Para reutilizar o módulo em outro projeto, copie o diretório inteiro
`python/21_blackjack/app/matchmaking_client/` para dentro do projeto e instale
as dependências acima.

## Exemplo mínimo

```python
from matchmaking_client import find_opponent

oponente = find_opponent(
    match_server="192.168.1.10:50051",
    advertise_ip="192.168.1.25",
    listen_port=41000,
    player_name="Alice",
    timeout=125,
)

print(f"Oponente: {oponente.ip}:{oponente.port}")
print(f"Minha vez de iniciar: {oponente.starts}")
print(f"Identificador da partida: {oponente.match_id}")
```

`find_opponent` é síncrona: a execução fica aguardando a resposta do servidor
até encontrar outro jogador ou ocorrer um erro/timeout. O canal gRPC é fechado
ao terminar a chamada, inclusive se ela falhar.

## Parâmetros

| Parâmetro | Obrigatório | Descrição |
|---|---:|---|
| `match_server` | Sim | Endereço `HOST:PORT` do servidor gRPC, por exemplo `match.example.com:50051`. |
| `advertise_ip` | Sim | IP deste jogador que o oponente poderá alcançar. Não é necessariamente o IP usado para acessar o servidor de matchmaking. |
| `listen_port` | Sim | Porta TCP em que o jogo deste jogador está aguardando conexões. Deve estar entre `1` e `65535`. |
| `player_name` | Não | Nome informativo enviado ao servidor; o padrão é `"player"`. |
| `timeout` | Não | Tempo máximo da chamada gRPC em segundos; o padrão é `125`. |

O `advertise_ip` e a `listen_port` precisam ser válidos também do ponto de vista
da rede: o outro jogador deve conseguir abrir uma conexão com esse endereço e
essa porta. Se os jogadores estiverem em máquinas diferentes, considere
firewall, NAT, roteamento e encaminhamento de portas.

**Abra a porta de escuta do jogo antes de chamar `find_opponent`.** O servidor
de matchmaking somente troca os endereços informados; ele não abre portas nem
encaminha a conexão de jogo.

## Dados retornados

A função retorna uma instância imutável de `Opponent` com estes campos:

- `ip`: endereço anunciado pelo oponente.
- `port`: porta de jogo anunciada pelo oponente.
- `starts`: indica qual jogador deve iniciar a conexão de jogo. Se for
  `True`, este cliente deve conectar ao IP e à porta retornados. Se for
  `False`, este cliente deve aguardar a conexão do oponente na própria porta
  anunciada.
- `match_id`: identificador atribuído pelo servidor para esta partida.

Exemplo de integração com um socket TCP:

```python
import socket

from matchmaking_client import find_opponent

servidor_de_jogo = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
servidor_de_jogo.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
servidor_de_jogo.bind(("0.0.0.0", 41000))
servidor_de_jogo.listen(1)

try:
    oponente = find_opponent(
        match_server="192.168.1.10:50051",
        advertise_ip="192.168.1.25",
        listen_port=41000,
        player_name="Alice",
    )

    if oponente.starts:
        conexao = socket.create_connection((oponente.ip, oponente.port))
    else:
        conexao, endereco = servidor_de_jogo.accept()

    with conexao:
        print(f"Conectado para a partida {oponente.match_id}")
        # A partir daqui, use o protocolo de jogo do seu projeto.
finally:
    servidor_de_jogo.close()
```

Adapte esse trecho ao modelo de conexão do seu jogo. A decisão de conexão
precisa ser coerente entre os dois jogadores: um lado conecta e o outro aceita.

## Tratamento de erros

Argumentos locais inválidos causam `ValueError` antes da chamada RPC, por
exemplo uma porta fora do intervalo permitido ou um endereço vazio.

Falhas gRPC são propagadas como `grpc.RpcError`. Isso inclui falha de conexão,
indisponibilidade do servidor e timeout. O chamador decide se deve informar o
erro ao usuário, tentar novamente ou cancelar a busca:

```python
import grpc

from matchmaking_client import find_opponent

try:
    oponente = find_opponent(
        "192.168.1.10:50051",
        "192.168.1.25",
        41000,
        player_name="Alice",
    )
except ValueError as erro:
    print(f"Configuração inválida: {erro}")
except grpc.RpcError as erro:
    print(f"Falha ao buscar partida: {erro.code().name}: {erro.details()}")
```

O timeout da chamada cliente deve ser maior que o tempo máximo de espera
configurado no servidor. Neste projeto, o servidor pode aguardar até `120`
segundos e o padrão do cliente é `125` segundos, deixando uma pequena margem
para a resposta RPC.

## Segurança e transporte

O cliente usa `grpc.insecure_channel`, isto é, a conexão gRPC não usa TLS. Use
essa configuração somente em redes confiáveis ou de desenvolvimento. Para
exposição em redes não confiáveis, o cliente e o servidor precisam ser
configurados para usar credenciais TLS.

O transporte de gameplay não faz parte da solicitação de matchmaking. O
servidor não inspeciona nem negocia o transporte que os jogadores usarão entre
si; essa escolha e sua compatibilidade são responsabilidade do jogo.

## Atualizar o contrato gRPC

O contrato compartilhado está em `proto/matchmaking.proto`. Depois de alterá-lo,
regenere os stubs Python a partir da raiz do repositório:

```sh
./.venv/bin/python python/21_blackjack/generate_proto.py
```

O script grava os arquivos gerados dentro deste diretório e ajusta o import do
stub gRPC para que funcione como parte do pacote `matchmaking_client`. O build
também os regenera automaticamente. Não edite os stubs à mão.

## Prompt para adaptar a busca a outro jogo com ajuda de uma IA

Copie o prompt abaixo para a IA que estiver ajudando no desenvolvimento do
novo jogo. Preencha os campos entre colchetes e, se possível, forneça também
os arquivos relevantes do projeto novo e deste diretório.

```text
Estou integrando ao meu jogo um cliente Python independente para buscar um
oponente em um servidor gRPC de matchmaking. Ajude-me a encaixar essa busca
na arquitetura do meu jogo sem misturar o matchmaking às regras ou ao
protocolo específico do jogo atual.

Contexto do meu jogo:
- Linguagem e versão: [ex.: Python 3.12]
- Como o jogo inicia uma partida: [descreva ou indique os arquivos]
- Transporte entre jogadores: [TCP, UDP, WebSocket, outro]
- Endereço local em que o jogador pode receber conexões: [como é obtido]
- Quem controla o ciclo de vida da partida: [módulo/classe]

Cliente de matchmaking disponível:
- Importação: `from matchmaking_client import find_opponent`
- Chamada síncrona:
  `find_opponent(match_server, advertise_ip, listen_port,
                 player_name="", timeout=125)`
- `match_server`: endereço HOST:PORT do servidor gRPC de matchmaking.
- `advertise_ip`: IP deste jogador alcançável pelo oponente; pode ser
  diferente do endereço usado para falar com o servidor de matchmaking.
- `listen_port`: porta em que o jogo deste jogador já está escutando.
- `player_name`: nome informativo do jogador.
- `timeout`: tempo máximo da chamada gRPC em segundos.
- O retorno é um `Opponent` imutável com `ip`, `port`, `starts` e `match_id`.
- Se `starts` for `True`, este cliente inicia a conexão com
  `(opponent.ip, opponent.port)`. Se for `False`, o cliente aguarda uma
  conexão na porta local anunciada.
- Erros de argumentos são `ValueError`; erros da chamada gRPC são
  `grpc.RpcError`.
- O módulo contém somente o cliente de matchmaking. Ele não conecta os
  jogadores entre si, não abre portas, não implementa TLS e não contém regras
  ou mensagens do jogo atual.

Tarefas:
1. Inspecione primeiro os arquivos relevantes e explique brevemente como o
   fluxo de partida do meu jogo funciona hoje.
2. Identifique onde criar/ativar a escuta local, quando chamar
   `find_opponent` e como usar `Opponent` para iniciar a partida.
3. Faça a integração mínima e modular. Mantenha regras, interface e protocolo
   de gameplay do meu jogo separados do cliente gRPC.
4. Garanta que o socket/servidor local esteja pronto antes de anunciar seu IP
   e porta. Faça com que um jogador conecte e o outro aceite, usando `starts`,
   para evitar que ambos conectem ou ambos aguardem.
5. Trate `ValueError`, `grpc.RpcError`, falhas de socket, cancelamento e
   encerramento, liberando corretamente canais, sockets e outros recursos.
   Não esconda erros com retornos de sucesso falsos.
6. Preserve o comportamento existente do jogo que não esteja relacionado à
   busca de oponente. A solicitação RPC não anuncia o transporte de gameplay;
   mantenha essa configuração no próprio jogo e não presuma que o servidor
   negocia compatibilidade de transporte.
7. Adicione ou atualize testes para o fluxo integrado e execute os testes
   relevantes. Informe quais arquivos alterou e como executar o jogo.

Se faltar informação sobre endereço anunciável, porta, transporte, ciclo de
vida ou comportamento esperado, pergunte antes de assumir. Não copie para o
novo jogo regras, sockets, multicast, mensagens ou interface do jogo de
referência; reutilize somente a integração necessária com o cliente de
matchmaking.
```
