# 21_blackjack

## Partida pela rede com servidor de matchmaking

O modo multiplayer está em `app/`. Cada jogador consulta o servidor gRPC de
matchmaking; quando o servidor encontra um par, um jogador inicia a conexão
TCP e o outro aceita essa conexão. O Blackjack continua usando o protocolo TCP
e as regras que já existiam no jogo.

### Dependências

Na raiz do repositório MatchPlayersServer, prepare o ambiente Python e instale
as dependências do cliente gRPC. Em Ubuntu/Lubuntu, instale `python3-venv` se
necessário:

```sh
sudo apt install python3-venv
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

### Iniciar o servidor de matchmaking

Em uma máquina acessível pelos dois jogadores, inicie o servidor na porta
escolhida, por exemplo `50051`. O endereço que os clientes usarão é o IP dessa
máquina e a porta:

```sh
./build/match_server 50051
```

### Iniciar os dois jogadores

Em cada máquina, execute o jogo apontando para o endereço do servidor. O IP
anunciado é detectado automaticamente pela rota até o servidor. Se houver NAT,
mais de uma interface de rede ou a detecção escolher um endereço incorreto,
informe o endereço alcançável pelo outro jogador com `--ip`.

No primeiro computador:

```sh
.venv/bin/python \
  python/21_blackjack/app/vinteum.py 192.168.1.10:50051 \
  --porta 41000 --nome Alice
```

No segundo computador, use o mesmo endereço de matchmaking, mas anuncie o IP
do segundo computador:

```sh
.venv/bin/python \
  python/21_blackjack/app/vinteum.py 192.168.1.10:50051 \
  --porta 41000 --ip 192.168.1.21 --nome Bruno
```

Substitua `192.168.1.10` pelo IP da máquina que executa o servidor e configure
`--ip` com o endereço de cada computador cliente quando necessário. Se ambos
os jogadores estiverem na mesma máquina, escolha portas diferentes com
`--porta`.

O fluxo do cliente é:

1. abre a porta TCP local para que ela já esteja pronta antes do pareamento;
2. envia ao servidor o IP anunciável, a porta e o nome;
3. usa `starts` da resposta: `True` inicia a conexão TCP ao oponente; `False`
   aceita a conexão na porta local;
4. inicia a partida existente e fecha os sockets ao terminar.

O primeiro jogador que entrar na fila recebe `starts=True` e assume o papel de
Dealer; o segundo aguarda a conexão. Esse campo escolhe quem inicia a conexão,
não quem faz a primeira jogada. O servidor só troca os endereços: não encaminha
conexões nem atravessa NAT. A porta TCP do jogo precisa ser alcançável entre os
jogadores, além da porta gRPC do servidor.

Para executar com depuração, acrescente `--debug`. Para ver as opções:

```sh
.venv/bin/python \
  python/21_blackjack/app/vinteum.py --help
```

### Testes da integração

Na raiz do repositório:

```sh
.venv/bin/python -m unittest discover \
  -s python/21_blackjack/tests -p 'test_*.py'
```