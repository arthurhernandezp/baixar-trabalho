from pathlib import Path

from grpc_tools import protoc


GAME_DIR = Path(__file__).resolve().parent
PROTO_DIR = GAME_DIR.parents[1] / "proto"
OUTPUT_DIR = GAME_DIR / "app" / "matchmaking_client"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

result = protoc.main(
    [
        "grpc_tools.protoc",
        f"-I{PROTO_DIR}",
        f"--python_out={OUTPUT_DIR}",
        f"--grpc_python_out={OUTPUT_DIR}",
        str(PROTO_DIR / "matchmaking.proto"),
    ]
)

if result != 0:
    raise SystemExit(result)

grpc_module = OUTPUT_DIR / "matchmaking_pb2_grpc.py"
contents = grpc_module.read_text(encoding="utf-8")
absolute_import = "import matchmaking_pb2 as matchmaking__pb2"
relative_import = "from . import matchmaking_pb2 as matchmaking__pb2"
if absolute_import not in contents:
    raise RuntimeError("Não foi possível ajustar o import do módulo gRPC gerado")
grpc_module.write_text(contents.replace(absolute_import, relative_import), encoding="utf-8")
